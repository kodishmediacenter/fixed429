# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
# Plugin Info

ADDON_ID      = 'plugin.video.hidratuxedo'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "channel/UC48rkTlXjRd6pnqqBkdV0Mw/live"
YOUTUBE_CHANNEL_ID2 = "channel/UCSF_aFGIIIoWY30GVV19TKA/live"
YOUTUBE_CHANNEL_ID3 = "channel/UCKVlixycWmapnGQ_wht4cHQ/live"
YOUTUBE_CHANNEL_ID4 = "channel/UCZtmNrG53nmbq-Ww2VJrxEQ/live"
YOUTUBE_CHANNEL_ID5 = "channel/UCaFMdq6QrAAEx5k2cLlZNPA/live"
YOUTUBE_CHANNEL_ID6 = "channel/UCmpj_KlPHHSRCLMdqOK6BDQ/live"

icon1 = "https://elasticbeanstalk-us-east-1-909474674380.s3.us-east-1.amazonaws.com/lta_sul_logo_certo_f5613bf154.png"
icon2 = "https://elasticbeanstalk-us-east-1-909474674380.s3.us-east-1.amazonaws.com/lta_norte_logo_certo_b2b7882055.png"
icon3 = "https://elasticbeanstalk-us-east-1-909474674380.s3.us-east-1.amazonaws.com/logo_lck_2025_38837802d0.png"
icon4 = "https://elasticbeanstalk-us-east-1-909474674380.s3.us-east-1.amazonaws.com/logo_lec_1_d86e906b93.png"
icon5 = "https://yt3.googleusercontent.com/9KBcuViJ9zatIpExxMFp69F3qc6pWb2leMaRQHIcpTfJGQRqLyUpUxNDqf1tjYhseXlPbM7ciIo=s512-c-k-c0x00ffffff-no-rj"
icon10 = "https://yt3.googleusercontent.com/N-9mpOYVLDBtIjOtHK7x0K3VfZLohz85HB9O3CEx40VEdv8I2yM9khvxD4OxVaWlEfkYyEyYEAw=s512-c-k-c0x00ffffff-no-rj"



def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def main():
   addDir(title = "LTA Sul       (Brasil e Amarica do Sul)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID1+"/",thumbnail = icon1,)
   addDir(title = "LTA Norte     (EUA e America do Norte)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID2+"/",thumbnail = icon2,)
   addDir(title = "LCK           (Coreia)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID3+"/",thumbnail = icon3,)
   addDir(title = "LEC EMEA      (Europeu)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID4+"/",thumbnail = icon4,)
   addDir(title = "LPL           (China)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID5+"/",thumbnail = icon5,)
   addDir(title = "LCP           (Taiwan, Japão, Vietna e Australia)",url = "plugin://plugin.video.youtube/"+YOUTUBE_CHANNEL_ID6+"/",thumbnail = icon10,)
   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
