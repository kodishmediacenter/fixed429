import xbmc
import xbmcgui

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )







def conect():
    dialog = xbmcgui.Dialog()
    player = dialog.select('Hidra Tuxedo BBB ', ['Site 1','Site 2','','Seguidores em Tempo Real','Paredao'])

    if player == 0:
            url = "https://kodish.space/bbb.html"
            web_browser(url)
    if player == 1: 
            url = "https://kodish.space/bbb2.html"
            web_browser(url)
    if player == 2: 
            url = "https://kodish.space/bbb2.html"
            web_browser(url)            
    if player == 3: 
            url = "https://kodish.space/bbb3.html"
            web_browser(url)
    if player == 4: 
            url = "https://kodish.space/bbb4.html"
            web_browser(url)


